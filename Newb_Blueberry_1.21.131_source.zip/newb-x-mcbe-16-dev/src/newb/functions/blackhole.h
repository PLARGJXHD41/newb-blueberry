#ifndef BLACKHOLE_H
#define BLACKHOLE_H

// Black hole: event horizon, gravitational lensing, swirling accretion disk,
// photon ring and polar jets. Blue/purple theme.
vec3 nlNetherBlackHole(vec3 col, vec3 dir, float t) {
  #ifdef NL_BLACK_HOLE
    vec3 h = normalize(vec3(0.35, 0.25, 0.9));
    vec3 up = normalize(cross(h, vec3(0.0, 1.0, 0.0)));
    vec3 vt = cross(h, up);

    float d = clamp(dot(dir, h), -1.0, 1.0);
    float ang = acos(d);
    vec2 p = vec2(dot(dir, up), dot(dir, vt));
    float pl = length(p) + 0.0001;
    vec2 pn = p / pl;

    float core = 0.15;
    float edge = smoothstep(core, core + 0.012, ang);

    // lensing: bend the background around the hole
    float lens = 1.0 + 1.8 * exp(-(ang - core) * 7.0) * edge;
    col *= mix(1.0, lens, 0.6);

    // tilted accretion disk with swirl
    vec2 q = vec2(p.x, p.y * 3.2);
    float r = length(q);
    float a = atan2(q.y, q.x);
    float swirl = 0.5 + 0.5 * sin(6.0 * a - 5.0 * t + 14.0 * r);
    float swirl2 = 0.5 + 0.5 * sin(11.0 * a + 3.0 * t - 22.0 * r);
    float disk = smoothstep(0.17, 0.25, r) * (1.0 - smoothstep(0.42, 0.65, r));
    disk *= 0.45 + 0.55 * swirl * (0.6 + 0.4 * swirl2);
    float doppler = 0.6 + 0.8 * (0.5 + 0.5 * pn.x); // one side brighter

    // photon ring
    float ring = exp(-pow((ang - 0.2) / 0.014, 2.0)) + 0.5*exp(-pow((ang - 0.26) / 0.01, 2.0));
    // soft outer halo
    float halo = exp(-(ang - core) * 6.0) * edge;
    // polar jets
    float jet = exp(-pow(p.x / 0.025, 2.0)) * smoothstep(0.1, 0.2, abs(p.y)) * exp(-abs(p.y) * 5.0);
    jet *= step(0.0, d);

    vec3 blue = vec3(0.25, 0.45, 2.0);
    vec3 purple = vec3(0.8, 0.2, 2.2);
    vec3 white = vec3(1.6, 1.3, 2.4);
    float pulse = 0.9 + 0.1 * sin(t * 2.0);

    vec3 glow = mix(purple, blue, swirl) * disk * doppler * 3.4;
    glow += white * ring * 2.6;
    glow += blue * pow(max(0.0, sin(40.0 * a + 4.0 * t)), 8.0) * disk * 1.5; // sparks
    glow += purple * halo * 0.7;
    glow += blue * jet * 2.5;

    col *= edge;
    col += glow * pulse * step(0.0, d);
  #endif
  return col;
}

#endif
